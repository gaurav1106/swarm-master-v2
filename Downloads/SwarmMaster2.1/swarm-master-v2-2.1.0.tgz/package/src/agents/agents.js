import { BaseAgent } from './base.js';
export class ClaudeAgent     extends BaseAgent { async run(t) { return { output: `[claude] ${t}` }; } }
export class GeminiAgent     extends BaseAgent { async run(t) { return { output: `[gemini] ${t}` }; } }
export class HermesAgent     extends BaseAgent { async run(t) { return { output: `[hermes] ${t}` }; } }
export class CodexAgent      extends BaseAgent { async run(t) { return { output: `[codex] ${t}` }; } }
export class PerplexityAgent extends BaseAgent { async run(t) { return { output: `[perplexity] ${t}` }; } }
export class MockAgent       extends BaseAgent { async run(t) { return { output: `[mock] ${t}`, cost: { totalUsd: 0 } }; } }
