export class BaseAgent {
  constructor(opts = {}) { this.id = opts.id; this.tier = opts.tier ?? 'sonnet'; }
  async run(_task, _opts) { throw new Error('BaseAgent.run() must be implemented'); }
}
