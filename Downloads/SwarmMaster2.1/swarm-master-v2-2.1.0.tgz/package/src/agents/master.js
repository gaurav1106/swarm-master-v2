import { MockAgent } from './agents.js';
export class MasterAgent {
  constructor(opts = {}) { this.opts = opts; this._agent = new MockAgent({ id: 'mock' }); }
  async run(task) { return this._agent.run(task); }
  async resume(_runId) { throw new Error('No checkpoint to resume'); }
}
