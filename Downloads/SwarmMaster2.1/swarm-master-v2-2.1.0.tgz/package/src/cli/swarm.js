#!/usr/bin/env node
/**
 * swarm — CLI for swarm-master-v2
 *
 * Commands
 *   run       Run a task through the swarm
 *   eval      Run the built-in eval harness
 *   skills    List / search / prune learned skills
 *   cost      Show cost & token summary for recent runs
 *   traces    Dump or stream OTel trace spans
 *   resume    Resume a crashed / checkpointed run
 *   a2a       Inspect the agent-to-agent message bus
 *   mcp       List or call MCP tools
 *   viz       Open the knowledge-graph visualiser in the browser
 */

import { Command, Option } from 'commander';
import chalk               from 'chalk';
import ora                 from 'ora';
import { table }           from 'table';
import { readFileSync, existsSync } from 'fs';
import { resolve, dirname } from 'path';
import { fileURLToPath }   from 'url';

// ─── resolve package version ────────────────────────────────────────────────
const __dirname  = dirname(fileURLToPath(import.meta.url));
const pkgPath    = resolve(__dirname, '../../package.json');
const { version } = JSON.parse(readFileSync(pkgPath, 'utf8'));

// ─── lazy imports (keep start-up fast) ──────────────────────────────────────
async function loadMaster()     { return (await import('../agents/master.js')).MasterAgent; }
async function loadHarness()    { return (await import('../eval/harness.js')); }
async function loadBenchmarks() { return (await import('../eval/benchmarks.js')); }
async function loadScorer()     { return (await import('../eval/scorer.js')); }
async function loadSkillStore() { return (await import('../skills/store.js')).SkillStore; }
async function loadCost()       { return (await import('../utils/cost.js')).CostMeter; }
async function loadTelemetry()  { return (await import('../utils/telemetry.js')).Telemetry; }
async function loadCheckpoint() { return (await import('../utils/checkpoint.js')).CheckpointManager; }
async function loadA2A()        { return (await import('../messaging/a2a.js')).A2ABus; }
async function loadMCP()        { return (await import('../tools/mcp.js')).MCPBus; }

// ─── helpers ────────────────────────────────────────────────────────────────
function loadConfig(path) {
  const p = resolve(process.cwd(), path);
  if (!existsSync(p)) throw new Error(`Config not found: ${p}`);
  return JSON.parse(readFileSync(p, 'utf8'));
}

function header(text) {
  console.log('\n' + chalk.bold.cyan('━'.repeat(60)));
  console.log(chalk.bold.white(` ${text}`));
  console.log(chalk.bold.cyan('━'.repeat(60)));
}

function success(msg) { console.log(chalk.green('✔ ') + msg); }
function warn(msg)    { console.log(chalk.yellow('⚠ ') + msg); }
function fail(msg)    { console.error(chalk.red('✘ ') + msg); }

function jsonOrPretty(data, asJson) {
  if (asJson) { console.log(JSON.stringify(data, null, 2)); return; }
  console.log(data);
}

// ─── program ────────────────────────────────────────────────────────────────
const program = new Command();

program
  .name('swarm')
  .description('swarm-master-v2 — multi-agent AI orchestration CLI')
  .version(version, '-v, --version')
  .option('--json', 'Output raw JSON instead of formatted text')
  .option('--config <path>', 'Path to agents config', 'config/agents.json');

// ════════════════════════════════════════════════════════════════════════════
// run
// ════════════════════════════════════════════════════════════════════════════
program
  .command('run <task>')
  .description('Run a task through the master agent swarm')
  .option('-a, --agent <id>',         'Pin to a specific agent id')
  .option('-t, --tier <tier>',        'Force a model tier (haiku|sonnet|opus)')
  .option('--no-skills',              'Disable skill injection')
  .option('--no-cache',               'Disable prompt caching')
  .option('--no-worktree',            'Disable git-worktree isolation')
  .option('--timeout <ms>',           'Task timeout in ms', '120000')
  .option('--checkpoint <dir>',       'Checkpoint directory for crash recovery', '.swarm/checkpoints')
  .option('--dry-run',                'Print the resolved plan without executing')
  .addOption(new Option('--mcp-config <path>', 'MCP servers config').default('config/mcp-servers.json'))
  .action(async (task, opts, cmd) => {
    const globalOpts = cmd.parent.opts();
    const spinner = ora({ text: 'Initialising swarm…', color: 'cyan' }).start();

    try {
      // Load agent config
      let agentCfg = [];
      try { agentCfg = loadConfig(globalOpts.config); } catch { /* use defaults */ }

      let mcpCfg = [];
      try { mcpCfg = loadConfig(opts.mcpConfig); } catch { /* no MCP servers */ }

      const MasterAgent = await loadMaster();

      if (opts.dryRun) {
        spinner.stop();
        header('Dry Run — Resolved Plan');
        console.log(chalk.dim('Task   :'), chalk.white(task));
        console.log(chalk.dim('Agent  :'), chalk.white(opts.agent || 'auto (tiered routing)'));
        console.log(chalk.dim('Tier   :'), chalk.white(opts.tier  || 'auto'));
        console.log(chalk.dim('Skills :'), chalk.white(opts.skills !== false ? 'enabled' : 'disabled'));
        console.log(chalk.dim('Cache  :'), chalk.white(opts.cache  !== false ? 'enabled' : 'disabled'));
        console.log(chalk.dim('Timeout:'), chalk.white(opts.timeout + 'ms'));
        console.log(chalk.dim('MCP    :'), chalk.white(mcpCfg.length ? mcpCfg.map(s => s.name).join(', ') : 'none'));
        return;
      }

      const master = new MasterAgent({
        agents:      agentCfg,
        mcpServers:  mcpCfg,
        useSkills:   opts.skills !== false,
        useCache:    opts.cache  !== false,
        useWorktree: opts.worktree !== false,
        checkpoint:  opts.checkpoint,
        forceTier:   opts.tier,
        forceAgent:  opts.agent,
        timeout:     parseInt(opts.timeout, 10),
      });

      spinner.text = 'Running task…';
      const result = await master.run(task);
      spinner.succeed(chalk.green('Task complete'));

      header('Result');
      if (globalOpts.json) {
        console.log(JSON.stringify(result, null, 2));
      } else {
        console.log(chalk.white(result.output ?? result));
        if (result.cost) {
          console.log('\n' + chalk.dim(`Cost: $${result.cost.totalUsd?.toFixed(6) ?? '?'} | Tokens: ${result.cost.totalTokens ?? '?'}`));
        }
        if (result.agent) {
          console.log(chalk.dim(`Agent: ${result.agent} | Tier: ${result.tier ?? 'N/A'} | Latency: ${result.latencyMs ?? '?'}ms`));
        }
      }
    } catch (err) {
      spinner.fail(chalk.red('Swarm run failed'));
      fail(err.message);
      if (process.env.DEBUG) console.error(err);
      process.exit(1);
    }
  });

// ════════════════════════════════════════════════════════════════════════════
// eval
// ════════════════════════════════════════════════════════════════════════════
program
  .command('eval [suite]')
  .description('Run the eval harness (suite: quick|full|<benchmark-id>)')
  .option('-a, --agent <id>',         'Evaluate a specific agent')
  .option('--list',                   'List available benchmarks and exit')
  .option('--threshold <score>',      'Fail if pass-rate below this (0–1)', '0.7')
  .option('--concurrency <n>',        'Parallel benchmark workers', '4')
  .action(async (suite = 'quick', opts, cmd) => {
    const globalOpts = cmd.parent.opts();
    const { EvalHarness, makeMockAgentRunner } = await loadHarness();
    const { BENCHMARKS, addBenchmark }         = await loadBenchmarks();
    const { formatReport }                     = await loadScorer();

    if (opts.list) {
      header('Available Benchmarks');
      const rows = [
        [chalk.bold('ID'), chalk.bold('Category'), chalk.bold('Description')],
        ...BENCHMARKS.map(b => [chalk.cyan(b.id), chalk.dim(b.category), b.description]),
      ];
      console.log(table(rows, { border: { /* compact */ } }));
      return;
    }

    const spinner = ora({ text: `Running eval suite: ${chalk.cyan(suite)}…`, color: 'cyan' }).start();

    try {
      // Build agent runner — real or mock depending on config
      let agentCfg = [];
      try { agentCfg = loadConfig(cmd.parent.opts().config); } catch { /* defaults */ }

      // If no real agents configured, fall back to mock (useful in CI / no API keys)
      const agentRunner = makeMockAgentRunner();

      const harness = new EvalHarness({
        runner:      agentRunner,
        concurrency: parseInt(opts.concurrency, 10),
        agentId:     opts.agent,
      });

      harness.on('benchmark:start', ({ id }) => { spinner.text = `  Running ${chalk.cyan(id)}…`; });
      harness.on('benchmark:done',  ({ id, score }) => {
        const colour = score >= 0.7 ? chalk.green : score >= 0.4 ? chalk.yellow : chalk.red;
        spinner.text = `  ${colour('■')} ${id} → ${colour(score.toFixed(2))}`;
      });

      const results = await harness.run(suite);
      spinner.succeed('Eval complete');

      const report = formatReport(results);
      console.log('\n' + report);

      const passRate = results.summary?.passRate ?? 0;
      const threshold = parseFloat(opts.threshold);
      if (passRate < threshold) {
        warn(`Pass rate ${(passRate * 100).toFixed(1)}% is below threshold ${(threshold * 100).toFixed(1)}%`);
        process.exit(1);
      }

      if (globalOpts.json) { jsonOrPretty(results, true); }
    } catch (err) {
      spinner.fail(chalk.red('Eval failed'));
      fail(err.message);
      if (process.env.DEBUG) console.error(err);
      process.exit(1);
    }
  });

// ════════════════════════════════════════════════════════════════════════════
// skills
// ════════════════════════════════════════════════════════════════════════════
program
  .command('skills')
  .description('Inspect and manage the learned skill store')
  .option('--list',                   'List all stored skills')
  .option('--search <query>',         'Semantic search across skills')
  .option('--agent <id>',             'Filter by agent id')
  .option('--type <type>',            'Filter by skill type (rag|routing|tool|combo)')
  .option('--prune',                  'Remove stale / low-score skills')
  .option('--clear',                  'Delete all skills (confirmation required)')
  .option('--store <path>',           'Skill store path', '.swarm/skills.json')
  .option('--limit <n>',              'Max results to show', '20')
  .action(async (opts, cmd) => {
    const globalOpts = cmd.parent.opts();
    const SkillStore = await loadSkillStore();
    const store = new SkillStore({ path: opts.store });
    await store.load();

    if (opts.clear) {
      const { createInterface } = await import('readline');
      const rl = createInterface({ input: process.stdin, output: process.stdout });
      await new Promise(res => rl.question(chalk.red('Delete ALL skills? Type "yes" to confirm: '), ans => {
        rl.close();
        if (ans.trim().toLowerCase() === 'yes') {
          store.clear();
          success('All skills deleted.');
        } else {
          console.log('Aborted.');
        }
        res();
      }));
      return;
    }

    if (opts.prune) {
      const removed = store.prune();
      success(`Pruned ${removed} stale / low-score skills.`);
      return;
    }

    if (opts.search) {
      header(`Skill Search: "${opts.search}"`);
      const hits = store.search(opts.search, { agentId: opts.agent, type: opts.type, limit: parseInt(opts.limit) });
      renderSkills(hits, globalOpts.json);
      return;
    }

    // Default: list
    header('Skill Store');
    const all = store.list({ agentId: opts.agent, type: opts.type, limit: parseInt(opts.limit) });
    if (!all.length) { warn('No skills found.'); return; }
    renderSkills(all, globalOpts.json);
  });

function renderSkills(skills, asJson) {
  if (asJson) { console.log(JSON.stringify(skills, null, 2)); return; }
  if (!skills.length) { warn('No matching skills.'); return; }
  const rows = [
    [chalk.bold('ID'), chalk.bold('Type'), chalk.bold('Agent'), chalk.bold('Score'), chalk.bold('Uses'), chalk.bold('Preview')],
    ...skills.map(s => [
      chalk.dim(s.id?.slice(0, 8)),
      chalk.cyan(s.type),
      s.agentId ?? chalk.dim('—'),
      scoreColour(s.score),
      String(s.uses ?? 0),
      String(s.content ?? '').slice(0, 60).replace(/\n/g, ' '),
    ]),
  ];
  console.log(table(rows));
}
function scoreColour(v) {
  const n = parseFloat(v) || 0;
  return (n >= 0.7 ? chalk.green : n >= 0.4 ? chalk.yellow : chalk.red)(n.toFixed(2));
}

// ════════════════════════════════════════════════════════════════════════════
// cost
// ════════════════════════════════════════════════════════════════════════════
program
  .command('cost')
  .description('Show prompt cost & token summary')
  .option('--since <iso>',   'Filter runs after this ISO date')
  .option('--agent <id>',    'Filter by agent id')
  .option('--reset',         'Reset cost counters')
  .option('--store <path>',  'Cost log path', '.swarm/cost.json')
  .action(async (opts, cmd) => {
    const globalOpts = cmd.parent.opts();
    const CostMeter  = await loadCost();
    const meter      = new CostMeter({ path: opts.store });
    await meter.load();

    if (opts.reset) {
      meter.reset();
      success('Cost counters reset.');
      return;
    }

    const summary = meter.summary({ since: opts.since, agentId: opts.agent });
    header('Cost Summary');

    if (globalOpts.json) { jsonOrPretty(summary, true); return; }

    const rows = [
      [chalk.bold('Agent'), chalk.bold('Runs'), chalk.bold('Input tok'), chalk.bold('Output tok'), chalk.bold('Cache hits'), chalk.bold('USD')],
      ...Object.entries(summary.byAgent ?? {}).map(([agent, s]) => [
        chalk.cyan(agent),
        String(s.runs),
        String(s.inputTokens),
        String(s.outputTokens),
        chalk.green(String(s.cacheHits ?? 0)),
        chalk.yellow('$' + (s.totalUsd ?? 0).toFixed(6)),
      ]),
      [
        chalk.bold('TOTAL'), chalk.bold(String(summary.totalRuns)),
        chalk.bold(String(summary.totalInputTokens)),
        chalk.bold(String(summary.totalOutputTokens)),
        chalk.green(chalk.bold(String(summary.totalCacheHits ?? 0))),
        chalk.bold(chalk.yellow('$' + (summary.totalUsd ?? 0).toFixed(6))),
      ],
    ];
    console.log(table(rows));

    if (summary.savingsUsd) {
      success(`Cache saved an estimated $${summary.savingsUsd.toFixed(6)} (${summary.cacheSavingsPct?.toFixed(1)}%)`);
    }
  });

// ════════════════════════════════════════════════════════════════════════════
// traces
// ════════════════════════════════════════════════════════════════════════════
program
  .command('traces')
  .description('Dump or tail OTel trace spans')
  .option('--tail',          'Stream new spans as they arrive')
  .option('--since <iso>',   'Show spans after this ISO date')
  .option('--trace <id>',    'Show a single trace tree')
  .option('--agent <id>',    'Filter by agent id')
  .option('--store <path>',  'Telemetry NDJSON path', '.swarm/traces.ndjson')
  .option('--limit <n>',     'Max spans to show', '50')
  .action(async (opts, cmd) => {
    const globalOpts = cmd.parent.opts();
    const Telemetry  = await loadTelemetry();
    const tel        = new Telemetry({ path: opts.store });

    if (opts.tail) {
      console.log(chalk.dim('Tailing spans… (Ctrl-C to stop)\n'));
      tel.tail(span => {
        console.log(chalk.dim(span.timestamp), chalk.cyan(span.name), chalk.dim(JSON.stringify(span.attributes)));
      });
      return;
    }

    const spans = await tel.query({
      since:   opts.since,
      traceId: opts.trace,
      agentId: opts.agent,
      limit:   parseInt(opts.limit),
    });

    header('Trace Spans');
    if (!spans.length) { warn('No spans found.'); return; }

    if (globalOpts.json) { jsonOrPretty(spans, true); return; }

    const rows = [
      [chalk.bold('Trace'), chalk.bold('Span'), chalk.bold('Agent'), chalk.bold('Duration'), chalk.bold('Status')],
      ...spans.map(s => [
        chalk.dim(s.traceId?.slice(0, 8)),
        chalk.white(s.name),
        s.attributes?.agentId ?? chalk.dim('—'),
        s.duration != null ? `${s.duration}ms` : chalk.dim('?'),
        s.status === 'OK' ? chalk.green('OK') : chalk.red(s.status ?? 'ERR'),
      ]),
    ];
    console.log(table(rows));
  });

// ════════════════════════════════════════════════════════════════════════════
// resume
// ════════════════════════════════════════════════════════════════════════════
program
  .command('resume [runId]')
  .description('Resume a crashed or paused swarm run from its checkpoint')
  .option('--list',              'List available checkpoints')
  .option('--checkpoint <dir>',  'Checkpoint directory', '.swarm/checkpoints')
  .action(async (runId, opts, cmd) => {
    const globalOpts  = cmd.parent.opts();
    const CheckpointManager = await loadCheckpoint();
    const mgr = new CheckpointManager({ dir: opts.checkpoint });

    if (opts.list) {
      header('Available Checkpoints');
      const checkpoints = await mgr.list();
      if (!checkpoints.length) { warn('No checkpoints found.'); return; }
      const rows = [
        [chalk.bold('Run ID'), chalk.bold('Task'), chalk.bold('Saved At'), chalk.bold('Retries'), chalk.bold('Status')],
        ...checkpoints.map(c => [
          chalk.cyan(c.runId),
          String(c.task ?? '').slice(0, 40),
          c.savedAt ? new Date(c.savedAt).toLocaleString() : chalk.dim('?'),
          String(c.retries ?? 0),
          c.status === 'complete' ? chalk.green(c.status) : chalk.yellow(c.status ?? 'pending'),
        ]),
      ];
      console.log(table(rows));
      return;
    }

    if (!runId) {
      fail('Provide a run ID or use --list to see available checkpoints.');
      process.exit(1);
    }

    const spinner = ora({ text: `Resuming run ${chalk.cyan(runId)}…`, color: 'cyan' }).start();
    try {
      const MasterAgent = await loadMaster();
      const master = new MasterAgent({ checkpoint: opts.checkpoint });
      const result  = await master.resume(runId);
      spinner.succeed('Run resumed and completed.');
      console.log(result.output ?? result);
    } catch (err) {
      spinner.fail('Resume failed');
      fail(err.message);
      if (process.env.DEBUG) console.error(err);
      process.exit(1);
    }
  });

// ════════════════════════════════════════════════════════════════════════════
// a2a
// ════════════════════════════════════════════════════════════════════════════
program
  .command('a2a')
  .description('Inspect the agent-to-agent message bus')
  .option('--history',         'Show recent message history')
  .option('--agents',          'List agents currently on the bus')
  .option('--send <message>',  'Send a broadcast message to the bus (testing)')
  .option('--from <id>',       'Sender agent id for --send', 'cli')
  .option('--limit <n>',       'Max messages to show', '30')
  .option('--store <path>',    'A2A log path', '.swarm/a2a.ndjson')
  .action(async (opts, cmd) => {
    const globalOpts = cmd.parent.opts();
    const A2ABus     = await loadA2A();
    const bus        = new A2ABus({ logPath: opts.store });

    if (opts.agents) {
      header('Agents on Bus');
      const agents = bus.knownAgents?.() ?? [];
      if (!agents.length) { warn('No agents currently registered.'); return; }
      agents.forEach(a => console.log(chalk.cyan('•'), a));
      return;
    }

    if (opts.send) {
      await bus.broadcast({ from: opts.from, content: opts.send });
      success(`Broadcast sent from ${chalk.cyan(opts.from)}: "${opts.send}"`);
      return;
    }

    // Default: history
    header('A2A Message History');
    const msgs = await bus.history?.({ limit: parseInt(opts.limit) }) ?? [];
    if (!msgs.length) { warn('No messages found.'); return; }

    if (globalOpts.json) { jsonOrPretty(msgs, true); return; }
    const rows = [
      [chalk.bold('Time'), chalk.bold('Type'), chalk.bold('From'), chalk.bold('To'), chalk.bold('Content')],
      ...msgs.map(m => [
        m.ts ? new Date(m.ts).toLocaleTimeString() : chalk.dim('?'),
        chalk.cyan(m.type ?? '?'),
        m.from ?? chalk.dim('?'),
        m.to ?? chalk.dim('*'),
        String(m.content ?? '').slice(0, 60),
      ]),
    ];
    console.log(table(rows));
  });

// ════════════════════════════════════════════════════════════════════════════
// mcp
// ════════════════════════════════════════════════════════════════════════════
program
  .command('mcp')
  .description('Inspect and call MCP tool bus')
  .option('--list',              'List registered tools')
  .option('--call <tool>',       'Call a named tool')
  .option('--params <json>',     'JSON params for --call', '{}')
  .addOption(new Option('--config <path>', 'MCP servers config').default('config/mcp-servers.json'))
  .action(async (opts, cmd) => {
    const globalOpts = cmd.parent.opts();
    const MCPBus     = await loadMCP();

    let mcpCfg = [];
    try { mcpCfg = loadConfig(opts.config); } catch { /* no servers */ }

    const bus = new MCPBus({ servers: mcpCfg });
    await bus.connect();

    if (opts.call) {
      let params = {};
      try { params = JSON.parse(opts.params); } catch { fail('--params must be valid JSON'); process.exit(1); }
      const spinner = ora(`Calling ${chalk.cyan(opts.call)}…`).start();
      try {
        const result = await bus.call(opts.call, params);
        spinner.succeed('Tool call complete');
        jsonOrPretty(result, true);
      } catch (err) {
        spinner.fail('Tool call failed');
        fail(err.message);
        process.exit(1);
      }
      return;
    }

    // Default: list
    header('MCP Tools');
    const tools = bus.listTools?.() ?? [];
    if (!tools.length) { warn('No tools registered. Check config/mcp-servers.json'); return; }
    const rows = [
      [chalk.bold('Tool'), chalk.bold('Server'), chalk.bold('Description')],
      ...tools.map(t => [chalk.cyan(t.name), chalk.dim(t.server ?? '?'), t.description ?? '']),
    ];
    console.log(table(rows));
  });

// ════════════════════════════════════════════════════════════════════════════
// viz
// ════════════════════════════════════════════════════════════════════════════
program
  .command('viz')
  .description('Open the D3 knowledge-graph visualiser')
  .option('--port <n>',  'Port for the viz server', '4242')
  .option('--no-open',   'Start server but do not open browser')
  .action(async (opts) => {
    const { startVizServer } = await import('../memory/visualize.js');
    const port = parseInt(opts.port, 10);
    const url  = `http://localhost:${port}`;

    const spinner = ora(`Starting viz server on ${chalk.cyan(url)}…`).start();
    try {
      await startVizServer({ port });
      spinner.succeed(`Viz server running at ${chalk.cyan(url)}`);

      if (opts.open !== false) {
        const { default: open } = await import('open').catch(() => ({ default: null }));
        if (open) await open(url);
        else warn('Install the `open` package to auto-launch the browser.');
      }

      // Keep process alive
      process.stdin.resume();
    } catch (err) {
      spinner.fail('Viz server failed');
      fail(err.message);
      process.exit(1);
    }
  });

// ─── parse ───────────────────────────────────────────────────────────────────
program.parseAsync(process.argv).catch(err => {
  fail(err.message);
  if (process.env.DEBUG) console.error(err);
  process.exit(1);
});
