export const BENCHMARKS = [
  { id: 'fizzbuzz',    category: 'logic',     description: 'FizzBuzz up to 20',                  prompt: 'Write FizzBuzz output for 1-20 (one number/result per line).', judge: o => /fizz/i.test(o) && /buzz/i.test(o) ? 1 : 0 },
  { id: 'syllogism',   category: 'reasoning', description: '3-step deductive syllogism',          prompt: 'All humans are mortal. Socrates is human. Is Socrates mortal? Answer yes or no.', judge: o => /yes/i.test(o) ? 1 : 0 },
  { id: 'palindrome',  category: 'logic',     description: 'Detect + explain palindromes',        prompt: 'Is "racecar" a palindrome? Explain why.',  judge: o => /yes|palindrome/i.test(o) ? 1 : 0 },
  { id: 'bigO',        category: 'code',      description: 'Identify Big-O of a snippet',         prompt: 'What is the Big-O time complexity of a nested loop iterating n*n times?', judge: o => /O\s*\(\s*n\s*[2²]\s*\)|n\^2/i.test(o) ? 1 : 0 },
  { id: 'codeSmells',  category: 'code',      description: 'Name 3 code smells in a sample',      prompt: 'List 3 common code smells (e.g. long method, duplicated code, magic numbers).', judge: o => (o.match(/long method|duplicat|magic number|god class|dead code|coupling/gi) ?? []).length >= 2 ? 1 : 0 },
  { id: 'summarize',   category: 'language',  description: 'Summarise a paragraph in <=2 sentences', prompt: 'Summarise in <=2 sentences: "The mitochondrion is a double-membrane-bound organelle found in eukaryotic cells. It generates most of the cell\'s supply of ATP."', judge: o => o.trim().split(/[.!?]+/).filter(Boolean).length <= 3 ? 1 : 0.5 },
  { id: 'tsBullets',   category: 'language',  description: 'TypeScript doc -> 3 bullet features',  prompt: 'List 3 key features of TypeScript as bullet points.', judge: o => (o.match(/^[-*•]/gm) ?? []).length >= 3 ? 1 : 0 },
  { id: 'idempotency', category: 'knowledge', description: 'Define idempotency with an example',   prompt: 'Define idempotency and give a software example.', judge: o => /idempoten/i.test(o) ? 1 : 0 },
  { id: 'apiAcronym',  category: 'knowledge', description: 'Expand API + explain REST',            prompt: 'What does API stand for? Briefly explain REST.', judge: o => /application programming interface/i.test(o) ? 1 : 0 },
  { id: 'unitConvert', category: 'logic',     description: 'Convert 72F to Celsius',              prompt: 'Convert 72 degrees Fahrenheit to Celsius. Show your work.', judge: o => /22[.,]2/.test(o) ? 1 : 0 },
];
export function addBenchmark(b) { BENCHMARKS.push(b); }
