export function scoreResult({ output, judge, tier, latencyMs, maxTokens = 500 }) {
  const base     = judge(output ?? '');
  const tokenPen = Math.max(0, (output?.split(/\s+/).length ?? 0) - maxTokens) * 0.001;
  const tierBonus = tier === 'haiku' ? 0.05 : tier === 'opus' ? -0.02 : 0;
  return Math.min(1, Math.max(0, base - tokenPen + tierBonus));
}

export function aggregateResults(results) {
  const byBenchmark = {}, byAgent = {};
  let total = 0, passed = 0, totalCostUsd = 0, totalLatencyMs = 0;
  for (const r of results) {
    (byBenchmark[r.benchmarkId] ??= []).push(r);
    (byAgent[r.agentId ?? 'unknown'] ??= []).push(r);
    total++; if (r.score >= 0.7) passed++;
    totalCostUsd   += r.costUsd   ?? 0;
    totalLatencyMs += r.latencyMs ?? 0;
  }
  return { results, summary: { total, passed, passRate: total ? passed / total : 0, totalCostUsd, avgLatencyMs: total ? totalLatencyMs / total : 0 }, byBenchmark, byAgent };
}

export function formatReport(agg) {
  if (!agg.summary) agg = aggregateResults(agg.results ?? agg);
  const { summary, byBenchmark } = agg;
  const bar = '='.repeat(62);
  const lines = [
    bar,
    '  swarm-master-v2 Eval Report',
    bar,
    '  Pass rate : ' + ((summary.passRate ?? 0) * 100).toFixed(1) + '%   Tests: ' + summary.total + '  Passed: ' + summary.passed,
    '  Avg latency: ' + Math.round(summary.avgLatencyMs ?? 0) + 'ms   Total cost: $' + (summary.totalCostUsd ?? 0).toFixed(6),
    bar,
    '  By Benchmark',
  ];
  for (const [id, rs] of Object.entries(byBenchmark ?? {})) {
    const avg = rs.reduce((s, r) => s + (r.score ?? 0), 0) / rs.length;
    lines.push('  ' + (avg >= 0.7 ? 'PASS' : 'FAIL') + ' ' + id.padEnd(14) + ' avg=' + avg.toFixed(2));
  }
  lines.push(bar);
  return lines.join('\n');
}
