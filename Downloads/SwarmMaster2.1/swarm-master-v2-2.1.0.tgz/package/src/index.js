/**
 * swarm-master-v2 — public API v2.1
 * All 4 phases wired.
 */

// Agents
export { BaseAgent }                           from './agents/base.js';
export { ClaudeAgent, GeminiAgent, HermesAgent,
         CodexAgent, PerplexityAgent, MockAgent } from './agents/agents.js';
export { MasterAgent }                         from './agents/master.js';
export { AgentRegistry }                       from './agents/registry.js';

// Memory — unified service
export { MemoryService, KnowledgeGraph, VectorStore } from './memory/service.js';
export { HNSWIndex }                           from './memory/hnsw.js';
export { startVizServer }                      from './memory/visualize.js';

// Messaging
export { A2ABus }                              from './messaging/a2a.js';

// Tools
export { MCPBus }                              from './tools/mcp.js';

// Utils
export { CostMeter }                           from './utils/cost.js';
export { Telemetry }                           from './utils/telemetry.js';
export { WorktreeManager }                     from './utils/worktree.js';
export { ModelRouter }                         from './utils/router.js';
export { CheckpointManager }                   from './utils/checkpoint.js';
export { jailPath, safeSpawn, redact, redactString,
         validate, SCHEMAS, SecurityError }    from './utils/security.js';

// Eval
export { EvalHarness, makeMockAgentRunner }    from './eval/harness.js';
export { BENCHMARKS, addBenchmark }            from './eval/benchmarks.js';
export { scoreResult, aggregateResults,
         formatReport }                        from './eval/scorer.js';

// Skills
export { SkillStore }                          from './skills/store.js';
export { SkillExtractor }                      from './skills/extractor.js';
export { buildSkillContext, learnFromRun,
         withSkills }                          from './skills/injector.js';
export { ReasoningBank }                       from './skills/reasoning-bank.js';
