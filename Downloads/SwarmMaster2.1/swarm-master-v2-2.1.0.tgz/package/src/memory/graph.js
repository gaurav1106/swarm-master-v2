export class KnowledgeGraph {
  constructor(_opts) { this._nodes = new Map(); this._edges = []; }
  addNode(n) { this._nodes.set(n.id, n); }
  addEdge(e) { this._edges.push(e); }
  query(filter) { return [...this._nodes.values()].filter(n => !filter?.type || n.type === filter.type); }
}
