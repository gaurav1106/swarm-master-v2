export class VectorStore {
  constructor() { this._docs = []; }
  add(doc) { this._docs.push(doc); }
  search(query, k = 5) { return this._docs.slice(0, k).map(d => ({ ...d, score: 0.5 })); }
}
