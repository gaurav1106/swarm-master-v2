export async function startVizServer({ port = 4242 } = {}) {
  const { createServer } = await import('http');
  return new Promise((resolve, reject) => {
    const s = createServer((_req, res) => {
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end('<html><body><h1>swarm-master-v2 Knowledge Graph</h1></body></html>');
    });
    s.listen(port, () => resolve(s));
    s.on('error', reject);
  });
}
