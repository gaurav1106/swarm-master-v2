export class SkillExtractor {
  extract({ task, output, score, mcpCalls = [], a2aMessages = [], tier, agentId }) {
    const skills = [];
    if (score >= 0.7 && (output?.length ?? 0) > 50)
      skills.push({ type: 'rag', agentId, content: output, score, metadata: { task: task?.slice(0, 100) } });
    if (tier)
      skills.push({ type: 'routing', agentId, content: JSON.stringify({ tier, taskSignals: task?.slice(0, 80) }), score });
    if (mcpCalls.length > 0)
      skills.push({ type: 'tool', agentId, content: JSON.stringify(mcpCalls.map(c => c.name)), score });
    if (a2aMessages.length > 0)
      skills.push({ type: 'combo', agentId, content: JSON.stringify(a2aMessages.map(m => m.type)), score });
    return skills;
  }
}
