export class CostMeter {
  constructor(_opts) { this._runs = []; }
  async load() {}
  record(entry) { this._runs.push({ ...entry, ts: Date.now() }); }
  reset() { this._runs = []; }
  summary({ agentId, since } = {}) {
    let runs = this._runs;
    if (agentId) runs = runs.filter(r => r.agentId === agentId);
    if (since) runs = runs.filter(r => r.ts >= new Date(since).getTime());
    const byAgent = {};
    for (const r of runs) {
      const a = byAgent[r.agentId] ??= { runs: 0, inputTokens: 0, outputTokens: 0, cacheHits: 0, totalUsd: 0 };
      a.runs++; a.inputTokens += r.inputTokens ?? 0; a.outputTokens += r.outputTokens ?? 0;
      a.cacheHits += r.cacheHits ?? 0;
      a.totalUsd += ((r.inputTokens ?? 0) * 3e-6) + ((r.outputTokens ?? 0) * 15e-6);
    }
    const totalUsd = Object.values(byAgent).reduce((s, a) => s + a.totalUsd, 0);
    return {
      byAgent,
      totalRuns:         runs.length,
      totalInputTokens:  runs.reduce((s, r) => s + (r.inputTokens ?? 0), 0),
      totalOutputTokens: runs.reduce((s, r) => s + (r.outputTokens ?? 0), 0),
      totalCacheHits:    runs.reduce((s, r) => s + (r.cacheHits ?? 0), 0),
      totalUsd,
    };
  }
}
