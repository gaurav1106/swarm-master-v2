/**
 * telemetry.js — Phase 1 hardened
 * CVE-3: all span attributes run through redact() before writing
 */

import { randomBytes }           from 'crypto';
import { appendFileSync, mkdirSync, readFileSync, existsSync } from 'fs';
import { dirname }               from 'path';
import { redact, redactString, assertSafePath } from './security.js';

export class Telemetry {
  /**
   * @param {object} opts
   * @param {string} [opts.path]   NDJSON output file. null = memory-only.
   * @param {string} [opts.endpoint]  Optional OTLP HTTP endpoint for Jaeger.
   */
  constructor({ path = null, endpoint = null } = {}) {
    this._path     = path ? assertSafePath(path) : null; // CVE-1 on file path
    this._endpoint = endpoint;
    this._spans    = [];
    this._tails    = [];
  }

  /** Start a new span. Returns the span object to pass to endSpan(). */
  startSpan(name, attrs = {}) {
    const span = {
      name,
      traceId:    randomBytes(16).toString('hex'),
      spanId:     randomBytes(8).toString('hex'),
      attributes: redact(attrs), // CVE-3: scrub on intake
      startedAt:  Date.now(),
      status:     'IN_PROGRESS',
    };
    this._spans.push(span);
    return span;
  }

  /** End a span, flush to disk/endpoint, notify tails. */
  endSpan(span, attrs = {}) {
    const safeAttrs = redact(attrs); // CVE-3
    Object.assign(span, safeAttrs, {
      duration:  Date.now() - span.startedAt,
      timestamp: new Date().toISOString(),
      status:    safeAttrs.status ?? 'OK',
    });
    this._flush(span);
    for (const fn of this._tails) fn(span);
  }

  /** Query in-memory spans with optional filters */
  async query({ traceId, agentId, since, limit = 50 } = {}) {
    let spans = [...this._spans];
    if (traceId) spans = spans.filter(s => s.traceId === traceId);
    if (agentId) spans = spans.filter(s => s.attributes?.agentId === agentId);
    if (since)   spans = spans.filter(s => s.timestamp >= since);
    return spans.slice(-limit);
  }

  /** Register a callback invoked on each completed span */
  tail(fn) {
    this._tails.push(fn);
    return () => { this._tails = this._tails.filter(f => f !== fn); };
  }

  // ── Private ──────────────────────────────────────────────────────────────

  _flush(span) {
    if (this._path) {
      try {
        mkdirSync(dirname(this._path), { recursive: true });
        // CVE-3: re-redact the serialised line to catch any late mutations
        const line = JSON.stringify(redact(span));
        appendFileSync(this._path, line + '\n');
      } catch {}
    }

    if (this._endpoint) {
      // Best-effort OTLP export — errors are swallowed to never block the caller
      this._exportOTLP(span).catch(() => {});
    }
  }

  async _exportOTLP(span) {
    const body = JSON.stringify({
      resourceSpans: [{
        resource:   { attributes: [] },
        scopeSpans: [{
          scope: { name: 'swarm-master-v2' },
          spans: [{
            traceId:           span.traceId,
            spanId:            span.spanId,
            name:              span.name,
            startTimeUnixNano: String(span.startedAt * 1_000_000),
            endTimeUnixNano:   String((span.startedAt + span.duration) * 1_000_000),
            status:            { code: span.status === 'OK' ? 1 : 2 },
            attributes:        _objToOTLP(span.attributes),
          }],
        }],
      }],
    });
    await fetch(this._endpoint + '/v1/traces', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body,
    });
  }
}

function _objToOTLP(obj = {}) {
  return Object.entries(obj).map(([key, value]) => ({
    key,
    value: typeof value === 'number' ? { doubleValue: value }
         : typeof value === 'boolean' ? { boolValue: value }
         : { stringValue: String(value) },
  }));
}
